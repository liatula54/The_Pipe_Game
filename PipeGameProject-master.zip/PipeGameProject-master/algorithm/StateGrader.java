package algorithm;

public interface StateGrader<T> {

	public int Grade(State<T> s);
}
